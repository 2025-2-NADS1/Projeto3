﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EXEMPLO_02_CLIENT
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("COMANDOS VÁLIDOS:");
            Console.WriteLine("GET TIME");
            Console.WriteLine("GET TIME LONDON:");
            Console.WriteLine("GET DATE");
            Console.WriteLine("SET SUMMERTIME { TRUE | FALSE}");
            while (true)
            {
                #region LÊ COMANDO (MENSAGEM)
                Console.Write(">>");
                String msg = Console.ReadLine();
                #endregion

                #region CONECTA COM SERVIDOR
                String IPServer = "127.0.0.1";
                TcpClient client = new TcpClient();
                client.Connect(IPServer, 30000);
                #endregion

                #region ENVIA MENSAGEM
                
                Byte[] dados = System.Text.Encoding.UTF8.GetBytes(msg);
                NetworkStream stream = client.GetStream();
                stream.Write(dados, 0, dados.Length);
                #endregion

                #region RECEBE MENSAGEM
                Byte[] dadosLidos = new Byte[client.ReceiveBufferSize];
                int numBytes = stream.Read(dadosLidos, 0, dadosLidos.Length);
                String resposta = "";
                resposta = resposta + System.Text.Encoding.UTF8.GetString(dadosLidos, 0, numBytes);
                #endregion

                System.Console.WriteLine(resposta);
                client.Close();
            }
            Console.ReadKey();
        }
    }
}
