using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Entrega2_Palavras
{
    public partial class FormMain : Form
    {
        private int _editingId = -1;

        public FormMain()
        {
            InitializeComponent();
            LoadDifficulties();
            LoadGrid();
        }

        private void LoadDifficulties()
        {
            comboDificuldade.Items.Clear();
            comboDificuldade.Items.AddRange(new string[] { "Facil", "Media", "Dificil" });
            comboDificuldade.SelectedIndex = 0;
        }

        private void LoadGrid(string filterText = "")
        {
            string filter = null;
            if (!string.IsNullOrWhiteSpace(filterText))
            {
                var escaped = filterText.Replace("'", "''");
                filter = $"(Texto_Palavra LIKE '%{escaped}%' OR Dificuldade LIKE '%{escaped}%')";
            }

            var list = Database.GetPalavras(filter);
            dgvPalavras.DataSource = list;

            dgvPalavras.Columns["Id_Palavra"].HeaderText = "ID";
            dgvPalavras.Columns["Texto_Palavra"].HeaderText = "Texto";
            dgvPalavras.Columns["Dificuldade"].HeaderText = "Dificuldade";
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            ClearForm();
            txtTexto.Focus();
        }

        private void ClearForm()
        {
            _editingId = -1;
            txtTexto.Text = "";
            comboDificuldade.SelectedIndex = 0;
            btnSalvar.Text = "Salvar";
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            var texto = txtTexto.Text.Trim();
            var dif = comboDificuldade.SelectedItem?.ToString() ?? "Facil";

            if (string.IsNullOrEmpty(texto))
            {
                MessageBox.Show("Informe o texto da palavra.", "Validação",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTexto.Focus();
                return;
            }

            if (_editingId == -1)
            {
                Database.InsertPalavra(texto, dif);
            }
            else
            {
                Database.UpdatePalavra(_editingId, texto, dif);
            }

            LoadGrid();
            ClearForm();
        }

        private void dgvPalavras_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPalavras.CurrentRow == null) return;

            if (dgvPalavras.CurrentRow.DataBoundItem is Palavra p)
            {
                _editingId = p.Id_Palavra;
                txtTexto.Text = p.Texto_Palavra;
                comboDificuldade.SelectedItem = p.Dificuldade;
                btnSalvar.Text = "Atualizar";
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (_editingId == -1)
            {
                MessageBox.Show("Selecione uma palavra para excluir.", "Atenção",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Deseja excluir a palavra selecionada?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Database.DeletePalavra(_editingId);
                LoadGrid();
                ClearForm();
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            LoadGrid(txtBuscar.Text.Trim());
        }

        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            if (dgvPalavras.Rows.Count == 0)
            {
                MessageBox.Show("Nenhuma palavra para exportar.", "Exportar CSV",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var sfd = new SaveFileDialog())
            {
                sfd.Filter = "CSV|*.csv";
                sfd.FileName = "palavras_export.csv";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    using (var sw = new StreamWriter(sfd.FileName, false, System.Text.Encoding.UTF8))
                    {
                        sw.WriteLine("Id_Palavra,Texto_Palavra,Dificuldade");

                        foreach (DataGridViewRow row in dgvPalavras.Rows)
                        {
                            if (row.DataBoundItem is Palavra p)
                            {
                                string textoSeguro = p.Texto_Palavra.Replace("\"", "\"\"");
                                sw.WriteLine($"{p.Id_Palavra},\"{textoSeguro}\",{p.Dificuldade}");
                            }
                        }
                    }

                    MessageBox.Show("Exportado com sucesso!", "CSV",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
