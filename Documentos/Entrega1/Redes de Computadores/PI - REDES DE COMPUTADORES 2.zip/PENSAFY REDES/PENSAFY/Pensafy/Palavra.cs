namespace Entrega2_Palavras
{
    public class Palavra
    {
        public int Id_Palavra { get; set; }
        public string Texto_Palavra { get; set; }
        public string Dificuldade { get; set; }
    }
}
