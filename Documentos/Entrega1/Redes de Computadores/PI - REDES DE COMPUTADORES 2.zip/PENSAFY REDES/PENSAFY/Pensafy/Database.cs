using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;

namespace Entrega2_Palavras
{
    public static class Database
    {
        // The database file must be in the same folder as the executable
        private const string ConnectionString = "Data Source=PENSAFY.db;Version=3;Compress=True;";

        public static List<Palavra> GetPalavras(string filter = null)
        {
            var list = new List<Palavra>();
            using (var con = new SQLiteConnection(ConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = "SELECT Id_Palavra, Texto_Palavra, Dificuldade FROM Palavra" + (string.IsNullOrEmpty(filter) ? "" : " WHERE " + filter) + " ORDER BY Id_Palavra";
                    using (var rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            list.Add(new Palavra
                            {
                                Id_Palavra = rdr.GetInt32(0),
                                Texto_Palavra = rdr.IsDBNull(1) ? string.Empty : rdr.GetString(1),
                                Dificuldade = rdr.IsDBNull(2) ? string.Empty : rdr.GetString(2)
                            });
                        }
                    }
                }
            }
            return list;
        }

        public static int InsertPalavra(string texto, string dificuldade)
        {
            using (var con = new SQLiteConnection(ConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO Palavra (Texto_Palavra, Dificuldade) VALUES (@t, @d); SELECT last_insert_rowid();";
                    cmd.Parameters.AddWithValue("@t", texto);
                    cmd.Parameters.AddWithValue("@d", dificuldade);
                    var id = cmd.ExecuteScalar();
                    return Convert.ToInt32(id);
                }
            }
        }

        public static void UpdatePalavra(int id, string texto, string dificuldade)
        {
            using (var con = new SQLiteConnection(ConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = "UPDATE Palavra SET Texto_Palavra = @t, Dificuldade = @d WHERE Id_Palavra = @id";
                    cmd.Parameters.AddWithValue("@t", texto);
                    cmd.Parameters.AddWithValue("@d", dificuldade);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void DeletePalavra(int id)
        {
            using (var con = new SQLiteConnection(ConnectionString))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM Palavra WHERE Id_Palavra = @id";
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
