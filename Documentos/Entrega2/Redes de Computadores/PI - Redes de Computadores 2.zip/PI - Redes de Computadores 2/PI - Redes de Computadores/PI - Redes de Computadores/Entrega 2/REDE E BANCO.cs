using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Collections.Generic;
using System.Linq;

namespace EXEMPLO_02_SERVER_PENSAFY_FINAL
{
    class Program
    {
        /* Mapeamento de Comandos de Rede para o Banco de Dados SQL:
         * LOGIN [EMAIL] [SENHA]      => SELECT na tabela Usuario.
         * START PARTIDA [ID_USUARIO] [DIFICULDADE] => SELECT na Palavra; INSERT na Partida.
         * ATTEMPT [ID_USUARIO] [TENTATIVA_TEXTO] => INSERT na Tentativa; UPDATE em Partida, Usuario, Ranking.
         * GET RANKING                => SELECT na tabela Ranking.
         */
        
        static TcpListener tcpServer;
        static string myIP = "127.0.0.1";
        static bool fim = false;
        
        // --- SIMULAÇÃO DE ESTADO DE JOGO (SUBSTITUINDO O DB REAL) ---
        static Dictionary<int, string> ActiveMatches = new Dictionary<int, string>(); // Key: Id_Usuario, Value: Palavra_Secreta
        static int nextPartidaId = 500;
        // -----------------------------------------------------------

        static void Main(string[] args)
        {
            fim = false;
            tcpServer = new TcpListener(System.Net.IPAddress.Parse(myIP), 30000);
            tcpServer.Start();
            Thread threadServer = new Thread(serverListener);
            threadServer.Start();
            
            Console.WriteLine("Servidor Pensafy (Simulado) iniciado em " + myIP + ":30000");
            Console.WriteLine("Aguardando conexões de clientes...");
            Console.ReadLine();
            fim = true;
        }

        public static void serverListener()
        {
            while (!fim)
            {
                if (tcpServer.Pending()) 
                {
                    TcpClient client = tcpServer.AcceptTcpClient();
                    Thread thread = new Thread(() => responseMessage(client)); 
                    thread.Start();
                }
                else
                {
                    Thread.Sleep(50); 
                }
            }
        }

        public static void responseMessage(TcpClient client)
        {
            String msg = receiveTCPMessage(client);
            
            // Lógica de negócio (onde a interação com o DB seria feita)
            msg = handlePensafyRequest(msg); 
            
            sendTCPMessage(client, msg);
        }

        // --- LÓGICA DE NEGÓCIO E MUDANÇA DE ESTADO (handlePensafyRequest) ---
        
        private static string handlePensafyRequest(string msg)
        {
            String[] parse = msg.Trim().Split(' ');
            String resposta = "ERRO: Comando Invalido ou Nao Reconhecido.";

            try
            {
                if (parse.Length > 0)
                {
                    string command = parse[0].ToUpper();

                    if (command == "LOGIN" && parse.Length == 3)
                    {
                        resposta = SimularLogin(parse[1], parse[2]);
                    }
                    else if (command == "START" && parse.Length == 4 && parse[1].ToUpper() == "PARTIDA")
                    {
                        int idUsuario = int.Parse(parse[2]);
                        string dificuldade = parse[3];
                        resposta = SimularIniciarPartida(idUsuario, dificuldade);
                    }
                    else if (command == "ATTEMPT" && parse.Length == 3)
                    {
                        int idUsuario = int.Parse(parse[1]);
                        string tentativa = parse[2];
                        resposta = SimularRegistrarTentativa(idUsuario, tentativa);
                    }
                    else if (command == "GET" && parse.Length == 2 && parse[1].ToUpper() == "RANKING")
                    {
                        resposta = SimularGetRanking();
                    }
                    else
                    {
                        resposta = "ERRO: Sintaxe do comando invalida. Verifique a documentacao.";
                    }
                }
            }
            catch (FormatException)
            {
                resposta = "ERRO: ID_USUARIO deve ser um número inteiro.";
            }
            catch (Exception ex)
            {
                resposta = $"ERRO INTERNO: {ex.Message}";
                Console.WriteLine($"Exceção: {ex.ToString()}");
            }

            return resposta;
        }
        
        // --- SIMULAÇÃO DA DAL (Mapeamento direto para as tabelas SQL) ---
        
        private static string SimularLogin(string email, string senha)
        {
            // Mapeia para: SELECT Id_Usuario FROM Usuario WHERE Email = @email AND Senha_ = @senha
            Console.WriteLine($"[DB] SELECT na tabela Usuario...");
            if (email == "player@pensafy.com" && senha == "senha123") 
            {
                return $"LOGIN_OK ID:101"; 
            }
            return "LOGIN_FALHOU";
        }

        private static string SimularIniciarPartida(int idUsuario, string dificuldade)
        {
            // Mapeia para: SELECT Palavra e INSERT na Partida
            Console.WriteLine($"[DB] SELECT na Palavra e INSERT na Partida...");
            string palavraSecreta = (dificuldade.ToUpper() == "FACIL") ? "COMPUTADOR" : "ALGORITMO";
            
            int novaPartidaId = nextPartidaId++;
            ActiveMatches[idUsuario] = palavraSecreta; 

            return $"PARTIDA_INICIADA ID:{novaPartidaId} PALAVRA_TAMANHO:{palavraSecreta.Length}";
        }

        private static string SimularRegistrarTentativa(int idUsuario, string tentativa)
        {
            if (!ActiveMatches.ContainsKey(idUsuario))
            {
                return "ERRO: Nenhuma partida ativa encontrada.";
            }
            
            string palavraSecreta = ActiveMatches[idUsuario];
            bool acertou = tentativa.ToUpper() == palavraSecreta.ToUpper();
            int pontuacaoGanha = acertou ? 150 : 10;

            // Mapeia para: INSERT Tentativa, UPDATE Partida (Tentativas_Usadas, Pontuacao_Ganha), UPDATE Usuario (Pontuacao_Total)
            Console.WriteLine($"[DB] INSERT Tentativa e UPDATES em Partida/Usuario.");

            if (acertou)
            {
                ActiveMatches.Remove(idUsuario);
                return $"ACERTOU! Fim de Partida. Pontos Ganhos: {pontuacaoGanha}.";
            }
            else
            {
                return $"ERRO. Tentativa Registrada.";
            }
        }
        
        private static string SimularGetRanking()
        {
            // Mapeia para: SELECT em Ranking JOIN Usuario
            Console.WriteLine("[DB] SELECT na tabela Ranking...");
            return "RANKING: 1-Fatima(950), 2-Nicollas(820)";
        }
        
        // --- FUNÇÕES DE REDE TCP ---
        
        public static string receiveTCPMessage(TcpClient tcpClient)
        {
            string TCPMsg = "";
            NetworkStream stream = tcpClient.GetStream();
            Byte[] byteMsg = new Byte[tcpClient.ReceiveBufferSize];
            
            while (stream.DataAvailable)
            {
                int i = stream.Read(byteMsg, 0, byteMsg.Length);
                TCPMsg += System.Text.Encoding.ASCII.GetString(byteMsg, 0, i); 
            }
            return TCPMsg.Trim();
        }

        public static void sendTCPMessage(TcpClient tcpClient, String msg)
        {
            try
            {
                NetworkStream stream = tcpClient.GetStream();
                Byte[] byteMsg = System.Text.Encoding.UTF8.GetBytes(msg + Environment.NewLine); 
                
                if (stream.CanWrite)
                {
                    stream.Write(byteMsg, 0, byteMsg.Length);
                    stream.Flush();
                }
            }
            catch (Exception)
            {
                // Erro de comunicação, não precisa travar o servidor
            }
            finally
            {
                 if (tcpClient != null) 
                 {
                     tcpClient.Close();
                 }
            }
        }
    }
}