using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace EXEMPLO_02_SERVER_PENSAFY
{
    class Program
    {
        /* Comandos de Rede para o Pensafy (Simulando interação com o Banco de Dados SQL)
         * LOGIN [EMAIL] [SENHA]      => Verifica na tabela Usuario
         * GET PALAVRA [DIFICULDADE]  => Seleciona uma Palavra na tabela Palavra e inicia Partida
         * ANSWER [ID_USUARIO] [TENTATIVA_TEXTO] => Registra Tentativa e atualiza Partida/Usuario
         * GET RANKING                => Busca dados na tabela Ranking
         */
        
        static TcpListener tcpServer;
        static string myIP = "127.0.0.1";
        static bool fim = false;
        
        // Simulação de estado do jogo (em um sistema real, isso estaria no DB)
        static int nextUserId = 100;
        static int nextPartidaId = 500;
        static string currentPalavraSecreta = "REDE"; // Simula Palavra.Texto_Palavra

        static void Main(string[] args)
        {
            fim = false;
            tcpServer = new TcpListener(System.Net.IPAddress.Parse(myIP), 30000);
            tcpServer.Start();
            Thread threadServer = new Thread(() => serverListener());
            threadServer.Start();
            
            Console.WriteLine("Servidor Pensafy (Simulado) iniciado em " + myIP + ":30000");
            Console.WriteLine("Pressione [ENTER] para terminar...");
            Console.ReadLine();
            fim = true;
        }

        public static void serverListener()
        {
            while (!fim)
            {
                // Espera por clientes. Usa tcpServer.Pending() para não bloquear totalmente.
                if (tcpServer.Pending()) 
                {
                    TcpClient client = tcpServer.AcceptTcpClient();
                    Thread thread = new Thread(() => responseMessage(client));
                    thread.Start();
                }
                else
                {
                    Thread.Sleep(100); 
                }
            }
        }

        public static void responseMessage(TcpClient client)
        {
            // Ponto de entrada de comunicação de rede
            String msg = receiveTCPMessage(client);
            Console.WriteLine($"[LOG] Recebido: {msg}");
            
            // Lógica de negócio do Pensafy
            msg = handlePensafyRequest(msg); 
            
            Console.WriteLine($"[LOG] Enviando: {msg}");
            sendTCPMessage(client, msg);
        }

        // ----------------------------------------------------------------------
        // FUNÇÃO PRINCIPAL DE LÓGICA DE NEGÓCIO (INTERAGE COM A SIMULAÇÃO SQL)
        // ----------------------------------------------------------------------

        private static string handlePensafyRequest(string msg)
        {
            String[] parse = msg.Split(' ');
            String resposta = "ERRO: Comando Desconhecido ou Incompleto!";

            // 1. LOGIN: Acessa a tabela Usuario
            if (parse[0] == "LOGIN" && parse.Length == 3)
            {
                string email = parse[1];
                string senha = parse[2];
                // Simula SELECT na tabela Usuario para verificar Email e Senha_
                int idUsuario = SimularLogin(email, senha); 
                
                if (idUsuario > 0)
                {
                    resposta = $"LOGIN_OK ID:{idUsuario}";
                }
                else
                {
                    resposta = "ERRO: Credenciais Invalidas";
                }
            }
            // 2. GET PALAVRA: Acessa a tabela Palavra e inicia Partida
            else if (parse[0] == "GET" && parse[1] == "PALAVRA" && parse.Length == 3)
            {
                string dificuldade = parse[2];
                // Simula SELECT na tabela Palavra por Dificuldade e INSERT na tabela Partida
                string palavra = SimularGetPalavra(dificuldade); 
                int idPartida = nextPartidaId++;
                
                resposta = $"PARTIDA_INICIADA ID:{idPartida} PALAVRA:{palavra.Length} DIFICULDADE:{dificuldade}";
            }
            // 3. ANSWER: Acessa e atualiza Tentativa, Partida, e Usuario/Ranking
            else if (parse[0] == "ANSWER" && parse.Length == 3)
            {
                // ANSWER [ID_USUARIO] [TENTATIVA_TEXTO]
                int idUsuario = int.Parse(parse[1]);
                string tentativa = parse[2];

                // Simula INSERT Tentativa, UPDATE Partida (Tentativas_Usadas, Acertou, Pontuacao_Ganha), 
                // e UPDATE Usuario (Pontuacao_Total).
                resposta = SimularTentativa(idUsuario, tentativa); 
            }
            // 4. GET RANKING: Acessa a tabela Ranking
            else if (parse[0] == "GET" && parse[1] == "RANKING")
            {
                // Simula SELECT na tabela Ranking
                resposta = SimularGetRanking();
            }

            return resposta;
        }

        // ----------------------------------------------------------------------
        // SIMULAÇÃO DA CAMADA DE ACESSO A DADOS (DAL) - VINCULADA AO SQL
        // ----------------------------------------------------------------------

        /*
         * Estas funções seriam, em um ambiente real, o ponto onde você usaria 
         * comandos SQL reais para interagir com o banco de dados.
         */

        private static int SimularLogin(string email, string senha)
        {
            // SQL Real: SELECT Id_Usuario, Pontuacao_Total FROM Usuario WHERE Email = @email AND Senha_ = @senha
            Console.WriteLine($"[SQL SIMULADO] SELECT na tabela Usuario para login.");
            if (email == "aluno@fecap.br" && senha == "fecap123") 
            {
                return 101; // Retorna um Id_Usuario simulado com sucesso
            }
            return -1; // Falha na autenticação
        }

        private static string SimularGetPalavra(string dificuldade)
        {
            // SQL Real: SELECT Texto_Palavra FROM Palavra WHERE Dificuldade = @dificuldade ORDER BY RAND() LIMIT 1
            Console.WriteLine($"[SQL SIMULADO] SELECT na tabela Palavra com Dificuldade='{dificuldade}'.");
            
            // Simulação: A palavra secreta é definida.
            string palavraSecreta = "";
            if (dificuldade.ToUpper() == "FACIL")
            {
                palavraSecreta = "REDE";
            }
            else
            {
                palavraSecreta = "FIREWALL";
            }
            currentPalavraSecreta = palavraSecreta;

            // SQL Real: INSERT INTO Partida (Id_Partida, Id_Usuario, Palavra_Secreta, ...) VALUES (...)
            Console.WriteLine($"[SQL SIMULADO] INSERT na tabela Partida.");
            
            return palavraSecreta;
        }

        private static string SimularTentativa(int idUsuario, string tentativa)
        {
            // SQL Real 1: INSERT INTO Tentativa (Id_Partida, Tentativa_Texto, Resultado, Posicao) VALUES (...)
            Console.WriteLine($"[SQL SIMULADO] INSERT na tabela Tentativa.");

            // Lógica de gamificação (simulada)
            bool acertou = (tentativa.ToUpper() == currentPalavraSecreta);
            int pontuacaoGanha = acertou ? 100 : 10;
            string resultadoTexto = acertou ? "OK" : "ERRO";

            // SQL Real 2: UPDATE Partida SET Tentativas_Usadas = T+1, Acertou = @acertou, Pontuacao_Ganha = P+@pont WHERE ...
            Console.WriteLine($"[SQL SIMULADO] UPDATE na tabela Partida.");

            if (acertou)
            {
                // SQL Real 3: UPDATE Usuario SET Pontuacao_Total = P+@pont WHERE Id_Usuario = @idUsuario
                // SQL Real 4: INSERT/UPDATE na tabela Ranking e potencial INSERT na tabela Cupom
                Console.WriteLine($"[SQL SIMULADO] UPDATE nas tabelas Usuario, Ranking e Cupom.");
                return $"ACERTOU! Pontos Ganhos: {pontuacaoGanha}. Resultado Salvo.";
            }
            else
            {
                return $"ERRO na tentativa '{tentativa}'. Pontos: {pontuacaoGanha}. Resultado Salvo.";
            }
        }
        
        private static string SimularGetRanking()
        {
            // SQL Real: SELECT Id_Usuario, Posicao, Pontuacao FROM Ranking ORDER BY Posicao ASC LIMIT 10
            Console.WriteLine("[SQL SIMULADO] SELECT na tabela Ranking.");
            return "RANKING: 1-Alice(500), 2-Bob(450), 3-Charlie(400)";
        }
        
        // ----------------------------------------------------------------------
        // FUNÇÕES DE COMUNICAÇÃO TCP ORIGINAIS
        // ----------------------------------------------------------------------
        
        public static string receiveTCPMessage(TcpClient tcpClient)
        {
            string TCPMsg = "";
            int i;
            NetworkStream stream = tcpClient.GetStream();
            Byte[] byteMsg = new Byte[tcpClient.ReceiveBufferSize];
            int tentativa = 0;
            while (!stream.DataAvailable && tentativa < 10)
            {
                Thread.Sleep(50);
                tentativa++;
            }
            while (stream.DataAvailable)
            {
                i = stream.Read(byteMsg, 0, byteMsg.Length);
                TCPMsg = TCPMsg + System.Text.Encoding.ASCII.GetString(byteMsg, 0, i);
            }
            return TCPMsg.Trim();
        }

        public static void sendTCPMessage(TcpClient tcpClient, String msg)
        {
            NetworkStream stream = tcpClient.GetStream();
            Byte[] byteMsg = System.Text.Encoding.UTF8.GetBytes(msg + Environment.NewLine); 
            if (stream.CanWrite)
            {
                stream.Write(byteMsg, 0, byteMsg.Length);
                stream.Flush();
            }
            else
            {
                // Problema de comunicação
            }
            tcpClient.Close();
        }
    }
}